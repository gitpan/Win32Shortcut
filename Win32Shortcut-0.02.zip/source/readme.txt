
To build Shortcut.pll, you will need:

	- the Perl5 source

You have to place the content of this directory in:

	(perl5)\dll-src\ext\win32\shortcut

where (perl5) is the path to your Perl5 source.

I've built it using Microsoft VC++ 4.0; please let me know if you have 
(or don't have) problems with other versions/compilers.

Send any comment to:

	Aldo Calpini	<dada@divinf.it>

